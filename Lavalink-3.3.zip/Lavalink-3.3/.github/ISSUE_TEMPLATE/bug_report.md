---
name: Bug report
about: Create a report to help us improve
title: ''
labels: ''
assignees: ''

---

## Description
<!-- Please describe the issue in details -->


## Version info
**Client used:**

Output of `java -jar Lavalink.jar --version`:
```
(paste here)
```

<!-- Remember to include Lavalink logs -->
